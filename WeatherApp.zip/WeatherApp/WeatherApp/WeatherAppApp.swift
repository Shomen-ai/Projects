//
//  WeatherAppApp.swift
//  WeatherApp
//
//  Created by Дмитрий Шайманов on 29.09.2021.
//

import SwiftUI

@main
struct WeatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
